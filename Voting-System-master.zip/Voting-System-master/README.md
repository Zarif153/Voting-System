# Voting System

Anonymous voting with AI-driven identity verification.

- `backend/` — Node.js + Express API, GPT-4o vision agent, Supabase storage
- `admin_frontend/` — React admin GUI (approve users, create polls, see results)
- `hello_world/` — Flutter app (register, upload NID/License + selfie, vote)

See **hosting.txt** for full setup, env-var, and deployment instructions.

Edit keys in:
- `backend/.env`
- `admin_frontend/.env`
- `hello_world/lib/config.dart`
