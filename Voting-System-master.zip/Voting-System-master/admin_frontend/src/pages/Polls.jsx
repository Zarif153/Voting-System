import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export default function Polls() {
  const [polls, setPolls] = useState([]);
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [opts, setOpts] = useState('Yes\nNo');
  const [err, setErr] = useState('');

  async function load() {
    const { polls } = await api('/admin/polls'); setPolls(polls);
  }
  useEffect(() => { load(); }, []);

  async function create(e) {
    e.preventDefault();
    setErr('');
    try {
      await api('/admin/polls', {
        method: 'POST',
        body: JSON.stringify({
          title, description: desc,
          options: opts.split('\n').map(s => s.trim()).filter(Boolean)
        })
      });
      setTitle(''); setDesc(''); setOpts('Yes\nNo');
      load();
    } catch (e) { setErr(e.message); }
  }

  return (
    <>
      <div className="card">
        <h2>Create Poll</h2>
        <form onSubmit={create}>
          <label>Title</label>
          <input value={title} onChange={e => setTitle(e.target.value)} />
          <label>Description</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} />
          <label>Options (one per line)</label>
          <textarea rows={4} value={opts} onChange={e => setOpts(e.target.value)} />
          {err && <div style={{ color: 'crimson' }}>{err}</div>}
          <button type="submit">Create</button>
        </form>
      </div>

      <div className="card">
        <h2>Polls</h2>
        <table>
          <thead><tr><th>Title</th><th>Created</th><th></th></tr></thead>
          <tbody>
            {polls.map(p => (
              <tr key={p.id}>
                <td>{p.title}</td>
                <td>{new Date(p.created_at).toLocaleString()}</td>
                <td><Link to={`/polls/${p.id}/results`}>Results</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
