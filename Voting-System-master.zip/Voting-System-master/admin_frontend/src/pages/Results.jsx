import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { api } from '../api.js';

export default function Results() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  useEffect(() => { api(`/admin/polls/${id}/results`).then(setData); }, [id]);
  if (!data) return <div className="card">Loading...</div>;

  return (
    <div className="card">
      <h2>Results</h2>
      <p>Total votes: {data.total}</p>
      {data.options.map(o => {
        const pct = data.total ? Math.round((o.votes / data.total) * 100) : 0;
        return (
          <div key={o.id} style={{ margin: '8px 0' }}>
            <div>{o.label} — {o.votes} ({pct}%)</div>
            <div style={{ background: '#e5e7eb', borderRadius: 4, height: 10 }}>
              <div style={{ width: `${pct}%`, background: '#2563eb', height: 10, borderRadius: 4 }} />
            </div>
          </div>
        );
      })}
      <p style={{ color: '#666' }}>Votes are anonymous — only aggregate counts are visible.</p>
    </div>
  );
}
