import React, { useEffect, useState } from 'react';
import { api } from '../api.js';

export default function Users() {
  const [users, setUsers] = useState([]);
  const [err, setErr] = useState('');

  async function load() {
    try { const { users } = await api('/admin/users'); setUsers(users); }
    catch (e) { setErr(e.message); }
  }
  useEffect(() => { load(); }, []);

  async function act(id, action) {
    await api(`/admin/users/${id}/${action}`, { method: 'POST' });
    load();
  }

  return (
    <div className="card">
      <h2>Users</h2>
      {err && <div style={{ color: 'crimson' }}>{err}</div>}
      <table>
        <thead><tr><th>Email</th><th>Name</th><th>ID Type</th><th>Encrypted ID #</th><th>Face Match</th><th>Remarks</th><th>Status</th><th>Role</th><th></th></tr></thead>
        <tbody>
          {users.map(u => (
            <tr key={u.id}>
              <td>{u.email}</td>
              <td>{u.full_name}</td>
              <td>{u.id_type}</td>
              <td
                title={u.id_number_encrypted || ''}
                style={{ fontFamily: 'monospace', fontSize: 11, maxWidth: 180, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}
              >
                {u.id_number_encrypted
                  ? <span style={{ color: '#555' }}>🔒 {u.id_number_encrypted.slice(0, 24)}…</span>
                  : '-'}
              </td>
              <td>{u.face_match_score?.toFixed?.(2) ?? '-'}</td>
              <td style={{ color: u.verification_remarks ? 'crimson' : '#666', maxWidth: 260, fontSize: 12 }}>
                {u.verification_remarks || '-'}
              </td>
              <td><span className={`badge ${u.status}`}>{u.status}</span></td>
              <td>{u.role}</td>
              <td>
                {u.status === 'pending' && <>
                  <button onClick={() => act(u.id, 'approve')}>Approve</button>{' '}
                  <button className="danger" onClick={() => act(u.id, 'reject')}>Reject</button>
                </>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <p style={{ color: '#666', marginTop: 12 }}>
        Note: ID numbers are stored as AES-256-GCM ciphertext. Admins can see the encrypted blob but cannot decrypt it.
      </p>
    </div>
  );
}
