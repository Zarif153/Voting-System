import React from 'react';
import { Routes, Route, Link, Navigate, useNavigate } from 'react-router-dom';
import Login from './pages/Login.jsx';
import Users from './pages/Users.jsx';
import Polls from './pages/Polls.jsx';
import Results from './pages/Results.jsx';
import { getToken, clearToken } from './api.js';

function Protected({ children }) {
  return getToken() ? children : <Navigate to="/login" />;
}

export default function App() {
  const nav = useNavigate();
  const logged = !!getToken();
  return (
    <>
      <nav>
        <strong>Voting Admin</strong>
        {logged && <>
          <Link to="/users">Users</Link>
          <Link to="/polls">Polls</Link>
        </>}
        <span className="spacer" />
        {logged && <button className="secondary" onClick={() => { clearToken(); nav('/login'); }}>Logout</button>}
      </nav>
      <div className="container">
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/users" element={<Protected><Users /></Protected>} />
          <Route path="/polls" element={<Protected><Polls /></Protected>} />
          <Route path="/polls/:id/results" element={<Protected><Results /></Protected>} />
          <Route path="*" element={<Navigate to={logged ? '/users' : '/login'} />} />
        </Routes>
      </div>
    </>
  );
}
