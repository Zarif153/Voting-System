import { Router } from 'express';
import { supabase } from '../db/supabase.js';
import { authRequired, adminOnly } from '../middleware/auth.js';

const router = Router();
router.use(authRequired, adminOnly);

// List users — NEVER return id_number_encrypted to admins.
router.get('/users', async (req, res) => {
  const { data, error } = await supabase
    .from('users')
    .select('id, email, full_name, role, status, id_type, face_match_score, verification_remarks, id_number_encrypted, created_at')
    .order('created_at', { ascending: false });
  if (error) return res.status(400).json({ error: error.message });
  res.json({ users: data });
});

router.post('/users/:id/approve', async (req, res) => {
  const { error } = await supabase.from('users').update({ status: 'approved' }).eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

router.post('/users/:id/reject', async (req, res) => {
  const { error } = await supabase.from('users').update({ status: 'rejected' }).eq('id', req.params.id);
  if (error) return res.status(400).json({ error: error.message });
  res.json({ ok: true });
});

router.post('/polls', async (req, res) => {
  const { title, description, options, ends_at } = req.body;
  if (!title || !Array.isArray(options) || options.length < 2)
    return res.status(400).json({ error: 'title and at least 2 options required' });

  const { data: poll, error } = await supabase.from('polls').insert({
    title, description, ends_at, created_by: req.user.sub
  }).select().single();
  if (error) return res.status(400).json({ error: error.message });

  const optRows = options.map(label => ({ poll_id: poll.id, label }));
  const { error: e2 } = await supabase.from('poll_options').insert(optRows);
  if (e2) return res.status(400).json({ error: e2.message });

  res.json({ poll });
});

router.get('/polls', async (req, res) => {
  const { data: polls } = await supabase.from('polls').select('*').order('created_at', { ascending: false });
  res.json({ polls });
});

router.get('/polls/:id/results', async (req, res) => {
  const { data: options } = await supabase.from('poll_options').select('*').eq('poll_id', req.params.id);
  const { data: votes } = await supabase.from('votes').select('option_id').eq('poll_id', req.params.id);
  const counts = {};
  for (const o of options) counts[o.id] = 0;
  for (const v of votes) counts[v.option_id] = (counts[v.option_id] || 0) + 1;
  res.json({
    options: options.map(o => ({ id: o.id, label: o.label, votes: counts[o.id] || 0 })),
    total: votes.length
  });
});

export default router;
