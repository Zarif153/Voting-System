import { Router } from 'express';
import { supabase } from '../db/supabase.js';
import { authRequired } from '../middleware/auth.js';
import { voterToken } from '../utils/crypto.js';

const router = Router();
router.use(authRequired);

router.get('/', async (req, res) => {
  const { data: polls } = await supabase.from('polls').select('*').order('created_at', { ascending: false });
  const { data: opts } = await supabase.from('poll_options').select('*');
  const grouped = polls.map(p => ({ ...p, options: opts.filter(o => o.poll_id === p.id) }));
  res.json({ polls: grouped });
});

router.get('/:id/results', async (req, res) => {
  const { data: poll } = await supabase.from('polls').select('*').eq('id', req.params.id).single();
  if (!poll) return res.status(404).json({ error: 'poll not found' });
  const { data: options } = await supabase.from('poll_options').select('*').eq('poll_id', req.params.id);
  const { data: votes } = await supabase.from('votes').select('option_id').eq('poll_id', req.params.id);
  const counts = {};
  for (const o of options) counts[o.id] = 0;
  for (const v of votes) counts[v.option_id] = (counts[v.option_id] || 0) + 1;
  res.json({
    poll: { id: poll.id, title: poll.title, description: poll.description, ends_at: poll.ends_at },
    options: options.map(o => ({ id: o.id, label: o.label, votes: counts[o.id] || 0 })),
    total: votes.length
  });
});

router.post('/:id/vote', async (req, res) => {
  // Only approved users can vote.
  const { data: u } = await supabase.from('users').select('status').eq('id', req.user.sub).single();
  if (!u || u.status !== 'approved') return res.status(403).json({ error: 'not approved to vote' });

  const { optionId } = req.body;
  if (!optionId) return res.status(400).json({ error: 'optionId required' });

  const token = voterToken(req.user.sub, req.params.id);
  const { error } = await supabase.from('votes').insert({
    poll_id: req.params.id, option_id: optionId, voter_token: token
  });
  if (error) {
    if (String(error.message).includes('duplicate')) return res.status(409).json({ error: 'already voted' });
    return res.status(400).json({ error: error.message });
  }
  res.json({ ok: true });
});

export default router;
