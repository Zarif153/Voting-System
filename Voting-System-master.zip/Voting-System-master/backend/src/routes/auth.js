import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import multer from 'multer';
import { supabase } from '../db/supabase.js';
import { encryptId, hashId } from '../utils/crypto.js';
import { verifyIdentity } from '../agent/verify.js';

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 8 * 1024 * 1024 } });
const router = Router();

router.post('/register', upload.fields([{ name: 'idImage' }, { name: 'selfie' }]), async (req, res) => {
  try {
    const { email, password, fullName, idType } = req.body;
    const bypassSelfie = String(req.body.bypassSelfie || '') === 'true';
    if (!email || !password) return res.status(400).json({ error: 'email and password required' });

    const idImage = req.files?.idImage?.[0]?.buffer;
    const selfie = req.files?.selfie?.[0]?.buffer;
    if (!idImage) return res.status(400).json({ error: 'idImage required' });

    const remarks = [];
    let idNumber = null;
    let faceMatch = null;

    if (selfie) {
      const v = await verifyIdentity({ idImage, selfieImage: selfie, idType });
      idNumber = v.idNumber;
      faceMatch = v.faceMatch;
      if (!v.idNumber) remarks.push(`Could not extract ID number${v.reason ? ': ' + v.reason : ''}`);
      if (v.faceMatch < 0.5) remarks.push(`Face did not match ID photo${v.reason ? ': ' + v.reason : ''}`);
    } else {
      remarks.push(bypassSelfie ? 'Selfie bypassed by user' : 'No selfie provided');
      const v = await verifyIdentity({ idImage, selfieImage: idImage, idType });
      idNumber = v.idNumber;
      if (!v.idNumber) remarks.push(`Could not extract ID number${v.reason ? ': ' + v.reason : ''}`);
    }

    const password_hash = await bcrypt.hash(password, 10);
    const { data, error } = await supabase.from('users').insert({
      email, password_hash, full_name: fullName,
      id_type: idType,
      id_number_encrypted: idNumber ? encryptId(idNumber) : null,
      id_number_hash: idNumber ? hashId(idNumber) : null,
      face_match_score: faceMatch,
      verification_remarks: remarks.length ? remarks.join(' | ') : null,
      status: 'pending',
      role: 'user'
    }).select('id, email, status, id_number_encrypted').single();
    if (error) return res.status(400).json({ error: error.message });

    res.json({
      user: data,
      id_number_encrypted: data.id_number_encrypted,
      message: 'Registration submitted. Awaiting admin approval.'
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const { data: user } = await supabase.from('users').select('*').eq('email', email).single();
  if (!user) return res.status(401).json({ error: 'invalid credentials' });
  const ok = await bcrypt.compare(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: 'invalid credentials' });
  const token = jwt.sign({ sub: user.id, role: user.role, email: user.email }, process.env.JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, email: user.email, role: user.role, status: user.status, full_name: user.full_name } });
});

export default router;
