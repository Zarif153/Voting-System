import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import { supabase, testConnection } from './db/supabase.js';
import authRoutes from './routes/auth.js';
import adminRoutes from './routes/admin.js';
import pollRoutes from './routes/polls.js';

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

app.use((req, _res, next) => { console.log(`[req] ${req.method} ${req.url}`); next(); });

app.get('/health', async (_, res) => {
  const db = await testConnection();
  res.status(db.ok ? 200 : 500).json({ ok: db.ok, db });
});
app.use('/auth', authRoutes);
app.use('/admin', adminRoutes);
app.use('/polls', pollRoutes);

async function bootstrapAdmin() {
  if (!process.env.SUPABASE_URL || !process.env.ADMIN_EMAIL) return;
  const { data } = await supabase.from('users').select('id').eq('role', 'admin').limit(1);
  if (data && data.length) return;
  const password_hash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'changeme', 10);
  await supabase.from('users').insert({
    email: process.env.ADMIN_EMAIL,
    password_hash, full_name: 'Admin',
    role: 'admin', status: 'approved'
  });
  console.log('[bootstrap] created admin', process.env.ADMIN_EMAIL);
}

const port = process.env.PORT || 4000;
app.listen(port, async () => {
  console.log(`backend listening on :${port}`);
  const db = await testConnection();
  if (!db.ok) {
    console.error('[startup] ❌ Supabase not connected. See db.txt for setup steps.');
  } else {
    try { await bootstrapAdmin(); } catch (e) { console.warn('bootstrap admin failed:', e.message); }
  }
});
