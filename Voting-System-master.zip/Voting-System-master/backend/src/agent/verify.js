import OpenAI from 'openai';

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

function dataUrl(buffer, mime = 'image/jpeg') {
  return `data:${mime};base64,${buffer.toString('base64')}`;
}

// Extract ID number from a NID/Driving License image and compare faces.
// Returns { idNumber, faceMatch (0-1), reason }.
export async function verifyIdentity({ idImage, selfieImage, idType }) {
  if (!process.env.OPENAI_API_KEY) {
    return { idNumber: null, faceMatch: 0, reason: 'OPENAI_API_KEY missing' };
  }

  const prompt = `You are an identity verification agent.
1. Extract the ${idType === 'license' ? 'Driving License' : 'NID'} number from the first image. Return digits/letters only, no spaces.
2. Compare the face on the ID (image 1) with the selfie (image 2). Decide if they are the same person.
Respond as strict JSON: {"id_number": "...", "same_person": true/false, "confidence": 0.0-1.0, "reason": "..."}`;

  const resp = await client.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{
      role: 'user',
      content: [
        { type: 'text', text: prompt },
        { type: 'image_url', image_url: { url: dataUrl(idImage) } },
        { type: 'image_url', image_url: { url: dataUrl(selfieImage) } }
      ]
    }],
    response_format: { type: 'json_object' }
  });

  let parsed = {};
  try { parsed = JSON.parse(resp.choices[0].message.content); } catch {}
  return {
    idNumber: parsed.id_number || null,
    faceMatch: parsed.same_person ? (parsed.confidence ?? 0.8) : 0,
    reason: parsed.reason || ''
  };
}
