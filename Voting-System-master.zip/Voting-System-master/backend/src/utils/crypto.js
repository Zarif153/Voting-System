import crypto from 'crypto';

const KEY_HEX = process.env.ENCRYPTION_KEY || '';
const KEY = KEY_HEX.length === 64 ? Buffer.from(KEY_HEX, 'hex') : null;

export function encryptId(plaintext) {
  if (!KEY) throw new Error('ENCRYPTION_KEY not configured (need 64 hex chars)');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const enc = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return [iv.toString('hex'), tag.toString('hex'), enc.toString('hex')].join(':');
}

export function hashId(plaintext) {
  return crypto.createHash('sha256').update(String(plaintext)).digest('hex');
}

export function voterToken(userId, pollId) {
  const secret = process.env.JWT_SECRET || 'fallback';
  return crypto.createHmac('sha256', secret).update(`${userId}:${pollId}`).digest('hex');
}
