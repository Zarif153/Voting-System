import { createClient } from '@supabase/supabase-js';

const url = process.env.SUPABASE_URL;
const key = process.env.SUPABASE_SERVICE_KEY;

console.log('[supabase] init — URL set:', !!url, '| SERVICE_KEY set:', !!key);
if (url) console.log('[supabase] URL:', url);

if (!url || !key) {
  console.error('[supabase] ❌ SUPABASE_URL or SUPABASE_SERVICE_KEY missing in .env — DB calls WILL fail.');
}

export const supabase = createClient(url || 'http://localhost', key || 'missing', {
  auth: { persistSession: false }
});

export async function testConnection() {
  if (!url || !key) return { ok: false, error: 'missing env vars' };
  try {
    const { error } = await supabase.from('users').select('id', { count: 'exact', head: true });
    if (error) {
      console.error('[supabase] ❌ connection test failed:', error.message);
      if (error.code === '42P01' || /relation .* does not exist/i.test(error.message || '')) {
        console.error('[supabase] ⚠️  table "users" not found — run schema.sql in Supabase SQL editor.');
      } else if (/Invalid API key|JWT/i.test(error.message || '')) {
        console.error('[supabase] ⚠️  bad SERVICE_KEY — copy the service_role key from Supabase → Settings → API.');
      }
      return { ok: false, error: error.message };
    }
    console.log('[supabase] ✅ connected — "users" table reachable');
    return { ok: true };
  } catch (e) {
    console.error('[supabase] ❌ connection test threw:', e.message);
    return { ok: false, error: e.message };
  }
}
