-- Run this in your Supabase SQL editor.

create table if not exists users (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  password_hash text not null,
  full_name text,
  role text not null default 'user', -- 'user' | 'admin'
  status text not null default 'pending', -- 'pending' | 'approved' | 'rejected'
  id_type text, -- 'nid' | 'license'
  id_number_encrypted text, -- AES-256-GCM payload, admins cannot decrypt
  id_number_hash text, -- sha256 hash for uniqueness check
  face_match_score real,
  verification_remarks text,
  created_at timestamptz default now()
);

-- If upgrading an existing DB, run:
-- alter table users add column if not exists verification_remarks text;

create table if not exists polls (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text,
  starts_at timestamptz default now(),
  ends_at timestamptz,
  created_by uuid references users(id),
  created_at timestamptz default now()
);

create table if not exists poll_options (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid references polls(id) on delete cascade,
  label text not null
);

-- Anonymous votes: we store an opaque voter_token (HMAC of user_id + poll_id with server secret)
-- so the admin cannot tie a vote back to a user, but a user cannot vote twice.
create table if not exists votes (
  id uuid primary key default gen_random_uuid(),
  poll_id uuid references polls(id) on delete cascade,
  option_id uuid references poll_options(id) on delete cascade,
  voter_token text not null,
  created_at timestamptz default now(),
  unique (poll_id, voter_token)
);
