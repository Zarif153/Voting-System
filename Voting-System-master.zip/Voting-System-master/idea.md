a voting system

1. User can sign in and register 
2. User will need to upload NID / Driving License and Pic to be eligible for vote. 
there will be ai agent that will extract NID number or Driving License Number and encode it. Also the taken picture will be compared with NID pic to see if the person is the same person or not. (we will be using GPT api) 


Admin can create poll where users can vote. Also after one user is signed up, admin will approve. But admin cant see their NID numbner or license number as it iwll be encoded.

Every vote will be anynomous. Since it will be encoded as well. 

Now you will create a WEB GUI for admin with backend. Use nodejs. As we need to host it so give me a hosting instruction in hosting.txt. 
The app will be done in flutter in different folder. 
Backend  in backend/ (stores api and agent)
app in hello_world/ (flutter)
admin frontend in admin_frontend/ (react js)

keep a file for keys where i can edit. 
like supabase keys. GPT api etc. Whatever key is needed put them in a .env or .config. 