import 'package:flutter/material.dart';
import '../api.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _pw = TextEditingController();
  String? _err;
  bool _busy = false;

  Future<void> _login() async {
    setState(() { _busy = true; _err = null; });
    try {
      final r = await Api.login(_email.text.trim(), _pw.text);
      await Api.setToken(r['token']);
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/polls');
    } catch (e) {
      setState(() => _err = e.toString());
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sign In')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
          TextField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
          const SizedBox(height: 12),
          if (_err != null) Text(_err!, style: const TextStyle(color: Colors.red)),
          const SizedBox(height: 12),
          ElevatedButton(onPressed: _busy ? null : _login, child: const Text('Sign In')),
          TextButton(
            onPressed: () => Navigator.pushNamed(context, '/register'),
            child: const Text('Register'),
          ),
        ]),
      ),
    );
  }
}
