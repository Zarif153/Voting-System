import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import '../api.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({super.key});
  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final _email = TextEditingController();
  final _pw = TextEditingController();
  final _name = TextEditingController();
  String _idType = 'nid';
  XFile? _idImage;
  XFile? _selfie;
  bool _bypassSelfie = false;
  String? _msg;
  bool _busy = false;

  Future<void> _pickId() async {
    final f = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (f != null) setState(() => _idImage = f);
  }

  Future<void> _pickSelfie(ImageSource src) async {
    final f = await ImagePicker().pickImage(source: src, imageQuality: 80);
    if (f != null) {
      setState(() {
        _selfie = f;
        _bypassSelfie = false;
      });
    }
  }

  Future<void> _chooseSelfieSource() async {
    final choice = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ListTile(
            leading: const Icon(Icons.camera_alt),
            title: const Text('Take selfie with camera'),
            onTap: () => Navigator.pop(ctx, 'camera'),
          ),
          ListTile(
            leading: const Icon(Icons.photo_library),
            title: const Text('Upload photo from gallery'),
            onTap: () => Navigator.pop(ctx, 'gallery'),
          ),
          ListTile(
            leading: const Icon(Icons.block),
            title: const Text('Skip / bypass selfie'),
            subtitle: const Text('Admin will review manually'),
            onTap: () => Navigator.pop(ctx, 'bypass'),
          ),
        ]),
      ),
    );
    if (choice == 'camera') await _pickSelfie(ImageSource.camera);
    else if (choice == 'gallery') await _pickSelfie(ImageSource.gallery);
    else if (choice == 'bypass') {
      setState(() {
        _selfie = null;
        _bypassSelfie = true;
      });
    }
  }

  Future<void> _submit() async {
    if (_idImage == null) {
      setState(() => _msg = 'Please upload your ID image');
      return;
    }
    if (_selfie == null && !_bypassSelfie) {
      setState(() => _msg = 'Add a selfie or choose "Skip / bypass"');
      return;
    }
    setState(() { _busy = true; _msg = null; });
    try {
      final r = await Api.register(
        email: _email.text.trim(),
        password: _pw.text,
        fullName: _name.text,
        idType: _idType,
        idImagePath: _idImage!.path,
        selfiePath: _selfie?.path,
        bypassSelfie: _bypassSelfie,
      );
      setState(() => _msg = r['message'] ?? 'Submitted');
      if (mounted && r['id_number_encrypted'] != null) {
        await _showEncryptedIdDialog(r['id_number_encrypted'].toString());
      }
    } catch (e) {
      setState(() => _msg = e.toString());
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _showEncryptedIdDialog(String ciphertext) async {
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Row(children: [
          Icon(Icons.lock, color: Colors.green),
          SizedBox(width: 8),
          Text('ID Encrypted'),
        ]),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text(
            'Your ID number has been encrypted with AES-256-GCM before being stored. '
            'Not even the admins can read your real ID — they only see the ciphertext below.',
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: Colors.black12,
              borderRadius: BorderRadius.circular(6),
            ),
            child: SelectableText(
              ciphertext,
              style: const TextStyle(fontFamily: 'monospace', fontSize: 11),
            ),
          ),
        ]),
        actions: [
          TextButton(
            onPressed: () {
              Clipboard.setData(ClipboardData(text: ciphertext));
              ScaffoldMessenger.of(ctx).showSnackBar(
                const SnackBar(content: Text('Copied')),
              );
            },
            child: const Text('Copy'),
          ),
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK')),
        ],
      ),
    );
  }

  String get _selfieLabel {
    if (_selfie != null) return 'Selfie added ✓';
    if (_bypassSelfie) return 'Selfie bypassed — admin review';
    return 'Add Selfie';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Register')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Full Name')),
          TextField(controller: _email, decoration: const InputDecoration(labelText: 'Email')),
          TextField(controller: _pw, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: _idType,
            decoration: const InputDecoration(labelText: 'ID Type'),
            items: const [
              DropdownMenuItem(value: 'nid', child: Text('NID')),
              DropdownMenuItem(value: 'license', child: Text('Driving License')),
            ],
            onChanged: (v) => setState(() => _idType = v ?? 'nid'),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: ElevatedButton(onPressed: _pickId, child: const Text('Upload ID'))),
            const SizedBox(width: 8),
            Expanded(child: ElevatedButton(onPressed: _chooseSelfieSource, child: Text(_selfieLabel))),
          ]),
          const SizedBox(height: 12),
          if (_idImage != null) Image.file(File(_idImage!.path), height: 100),
          if (_selfie != null) Image.file(File(_selfie!.path), height: 100),
          if (_bypassSelfie)
            const Padding(
              padding: EdgeInsets.only(top: 8),
              child: Text(
                'You chose to skip the selfie. Your account will still be created and flagged for admin review.',
                style: TextStyle(color: Colors.orange),
              ),
            ),
          const SizedBox(height: 12),
          if (_msg != null) Text(_msg!, style: const TextStyle(color: Colors.red)),
          ElevatedButton(onPressed: _busy ? null : _submit, child: const Text('Submit')),
        ]),
      ),
    );
  }
}
