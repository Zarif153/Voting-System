import 'package:flutter/material.dart';
import '../api.dart';

class ResultsScreen extends StatefulWidget {
  final String pollId;
  final String title;
  const ResultsScreen({super.key, required this.pollId, required this.title});

  @override
  State<ResultsScreen> createState() => _ResultsScreenState();
}

class _ResultsScreenState extends State<ResultsScreen> {
  Map<String, dynamic>? _data;
  String? _err;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _err = null; });
    try {
      final r = await Api.pollResults(widget.pollId);
      setState(() => _data = r);
    } catch (e) {
      setState(() => _err = e.toString());
    } finally {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final options = (_data?['options'] as List?) ?? [];
    final total = (_data?['total'] as int?) ?? 0;
    return Scaffold(
      appBar: AppBar(
        title: Text('Results — ${widget.title}'),
        actions: [IconButton(icon: const Icon(Icons.refresh), onPressed: _load)],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator())
        : _err != null
          ? Center(child: Text(_err!))
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text('Total votes: $total', style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 12),
                ...options.map((o) {
                  final votes = (o['votes'] as int?) ?? 0;
                  final pct = total == 0 ? 0.0 : votes / total;
                  return Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Expanded(child: Text(o['label'] ?? '', style: const TextStyle(fontWeight: FontWeight.w600))),
                            Text('$votes  (${(pct * 100).toStringAsFixed(1)}%)'),
                          ],
                        ),
                        const SizedBox(height: 8),
                        ClipRRect(
                          borderRadius: BorderRadius.circular(4),
                          child: LinearProgressIndicator(value: pct, minHeight: 10),
                        ),
                      ]),
                    ),
                  );
                }),
              ],
            ),
    );
  }
}
