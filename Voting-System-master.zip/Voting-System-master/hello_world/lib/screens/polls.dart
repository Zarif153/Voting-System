import 'package:flutter/material.dart';
import '../api.dart';
import 'results.dart';

class PollsScreen extends StatefulWidget {
  const PollsScreen({super.key});
  @override
  State<PollsScreen> createState() => _PollsScreenState();
}

class _PollsScreenState extends State<PollsScreen> {
  List<dynamic> _polls = [];
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await Api.polls();
      setState(() => _polls = p);
    } catch (e) {
      setState(() => _err = e.toString());
    }
  }

  Future<void> _vote(String pollId, String optionId) async {
    try {
      await Api.vote(pollId, optionId);
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Vote recorded')));
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Polls'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _load),
          IconButton(icon: const Icon(Icons.logout), onPressed: () async {
            await Api.clearToken();
            if (!mounted) return;
            Navigator.pushReplacementNamed(context, '/login');
          }),
        ],
      ),
      body: _err != null
        ? Center(child: Text(_err!))
        : ListView.builder(
            itemCount: _polls.length,
            itemBuilder: (_, i) {
              final p = _polls[i];
              final opts = (p['options'] as List?) ?? [];
              return Card(
                margin: const EdgeInsets.all(12),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p['title'] ?? '', style: Theme.of(context).textTheme.titleMedium),
                    if ((p['description'] ?? '').toString().isNotEmpty)
                      Padding(padding: const EdgeInsets.only(top: 4), child: Text(p['description'])),
                    const SizedBox(height: 8),
                    ...opts.map((o) => ListTile(
                      title: Text(o['label']),
                      trailing: ElevatedButton(
                        onPressed: () => _vote(p['id'], o['id']),
                        child: const Text('Vote'),
                      ),
                    )),
                    const SizedBox(height: 4),
                    Align(
                      alignment: Alignment.centerRight,
                      child: TextButton.icon(
                        icon: const Icon(Icons.bar_chart),
                        label: const Text('View Results'),
                        onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ResultsScreen(
                              pollId: p['id'],
                              title: p['title'] ?? '',
                            ),
                          ),
                        ),
                      ),
                    ),
                  ]),
                ),
              );
            },
          ),
    );
  }
}
