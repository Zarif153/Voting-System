// Edit this to point at your backend.
class AppConfig {
  static const String apiUrl = String.fromEnvironment(
    'API_URL',
    defaultValue: 'http://10.0.2.2:4000', // Android emulator -> host
  );
}
