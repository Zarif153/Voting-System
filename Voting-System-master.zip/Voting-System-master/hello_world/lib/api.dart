import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'config.dart';

class Api {
  static Future<String?> _token() async =>
      (await SharedPreferences.getInstance()).getString('token');

  static Future<void> setToken(String t) async =>
      (await SharedPreferences.getInstance()).setString('token', t);

  static Future<void> clearToken() async =>
      (await SharedPreferences.getInstance()).remove('token');

  static Future<Map<String, dynamic>> _req(String method, String path,
      {Map<String, dynamic>? body}) async {
    final uri = Uri.parse('${AppConfig.apiUrl}$path');
    final headers = {'Content-Type': 'application/json'};
    final t = await _token();
    if (t != null) headers['Authorization'] = 'Bearer $t';
    final res = await http.Request(method, uri)
      ..headers.addAll(headers)
      ..body = body == null ? '' : jsonEncode(body);
    final streamed = await res.send();
    final r = await http.Response.fromStream(streamed);
    final data = r.body.isEmpty ? {} : jsonDecode(r.body);
    if (r.statusCode >= 400) throw Exception(data['error'] ?? 'HTTP ${r.statusCode}');
    return Map<String, dynamic>.from(data);
  }

  static Future<Map<String, dynamic>> login(String email, String password) =>
      _req('POST', '/auth/login', body: {'email': email, 'password': password});

  static Future<Map<String, dynamic>> register({
    required String email,
    required String password,
    required String fullName,
    required String idType,
    required String idImagePath,
    String? selfiePath,
    bool bypassSelfie = false,
  }) async {
    final uri = Uri.parse('${AppConfig.apiUrl}/auth/register');
    final req = http.MultipartRequest('POST', uri)
      ..fields['email'] = email
      ..fields['password'] = password
      ..fields['fullName'] = fullName
      ..fields['idType'] = idType
      ..fields['bypassSelfie'] = bypassSelfie.toString()
      ..files.add(await http.MultipartFile.fromPath('idImage', idImagePath));
    if (selfiePath != null) {
      req.files.add(await http.MultipartFile.fromPath('selfie', selfiePath));
    }
    final r = await http.Response.fromStream(await req.send());
    final data = jsonDecode(r.body);
    if (r.statusCode >= 400) throw Exception(data['error'] ?? 'HTTP ${r.statusCode}');
    return Map<String, dynamic>.from(data);
  }

  static Future<List<dynamic>> polls() async {
    final r = await _req('GET', '/polls/');
    return r['polls'] as List<dynamic>;
  }

  static Future<void> vote(String pollId, String optionId) =>
      _req('POST', '/polls/$pollId/vote', body: {'optionId': optionId});

  static Future<Map<String, dynamic>> pollResults(String pollId) =>
      _req('GET', '/polls/$pollId/results');
}
