import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'screens/login.dart';
import 'screens/polls.dart';
import 'screens/register.dart';

void main() => runApp(const VotingApp());

class VotingApp extends StatelessWidget {
  const VotingApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Voting',
      theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true),
      home: const RootGate(),
      routes: {
        '/login': (_) => const LoginScreen(),
        '/register': (_) => const RegisterScreen(),
        '/polls': (_) => const PollsScreen(),
      },
    );
  }
}

class RootGate extends StatefulWidget {
  const RootGate({super.key});
  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> {
  @override
  void initState() {
    super.initState();
    _check();
  }

  Future<void> _check() async {
    final p = await SharedPreferences.getInstance();
    final t = p.getString('token');
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, t == null ? '/login' : '/polls');
  }

  @override
  Widget build(BuildContext context) =>
      const Scaffold(body: Center(child: CircularProgressIndicator()));
}
